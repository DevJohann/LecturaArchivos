package co.edu.unbosque.modelo;

import java.awt.Graphics;

import javax.swing.text.BadLocationException;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;

/**
 * Clase que implementa la interfaz de Highlighter para subrayar el texto encontrado
 * @author CryptedSec Team
 * @see Highlighter
 *
 */

public class Highlight implements Highlighter{

	@Override
	public void install(JTextComponent c) {
		
	}

	@Override
	public void deinstall(JTextComponent c) {
		
	}

	@Override
	public void paint(Graphics g) {
		
	}

	@Override
	public Object addHighlight(int p0, int p1, HighlightPainter p) throws BadLocationException {
		return null;
	}

	@Override
	public void removeHighlight(Object tag) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeAllHighlights() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeHighlight(Object tag, int p0, int p1) throws BadLocationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public javax.swing.text.Highlighter.Highlight[] getHighlights() {
		// TODO Auto-generated method stub
		return null;
	}

}
