package co.edu.unbosque.controlador;

public class AplMain {
	
	/**
	 * Puerta de entrada a la aplicación
	 * @param args
	 */

	public static void main(String[] args) {
		
		Controlador controlador = new Controlador();

	}

}
