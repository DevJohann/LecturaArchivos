package co.edu.unbosque.controlador;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.Highlighter.HighlightPainter;

import co.edu.unbosque.modelo.EjercicioArchivo;
import co.edu.unbosque.modelo.Highlight;
import co.edu.unbosque.modelo.KMP;
import co.edu.unbosque.vista.VistaPrincipal;
import co.edu.unbosque.vista.VistaVentanas;

/**
 * 
 * @author CryptedSec Team
 *
 */
public class Controlador implements ActionListener{
	
	private VistaPrincipal VP;
	private EjercicioArchivo EA;
	private VistaVentanas VV;
	private boolean checked;
	private Highlighter HL;
	
	/**
	 *<h2>Constructor<h2>
	 *Aquí instanciamos todos los objetos, asignamos oyentes, iniciamos el highlighter, 
	 *cargamos el archivo de texto por defecto, y verificamos que se haya cargado correctamente 
	 */
	public Controlador() {
		
		VP = new VistaPrincipal();
		asignarOyentes();
		EA = new EjercicioArchivo();
		VV = new VistaVentanas();
		HL = VP.getDerecha().getJCampoTexto().getHighlighter();
		VP.getDerecha().setCampoTexto(EA.readFile()); //Setear el texto del TextArea con la lectura del archivo
		checked = EA.checkLoaded();
		//System.out.println(checked); //Debug
		if(checked) {
			VP.getDatos().getArchivo().setText("Cargado");
		}
		
	}
	
	/**
	 * <h2>AsignarOyentes</h2>
	 * Asignamos oyentes a cada botón de la aplicación
	 */
	public void asignarOyentes() {
		VP.getIzquierda().getAgregar().addActionListener(this);
		VP.getIzquierda().getBuscar().addActionListener(this);
		VP.getIzquierda().getSalir().addActionListener(this);
	}

	/**
	 * <h2>ActionListener</h2>
	 * Aquí vemos cual botón fue presionado en base a su actionCommand asignado en vista, y
	 * en base a eso se realizan las acciones correspondientes
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand(); //Comandos en minúscula
		if(command.equals("agregar")) {
			String src = VP.getIzquierda().getEntradaTexto().getText();
			
			if(src.equals("")) {
				//System.out.println("Hola" + src); //Debug
				VV.MostrarInformacion("Debe agregar una ruta");
				//Mostrar en VP mensaje diciendo que debe ingresar una ruta
			}
			else {
				EA.loadFile(src);
				checked = EA.checkLoaded();
				System.out.println(checked); //Debug
				if(checked == false) {
					//System.out.println("Archivo no cargado"); //Debug
					VV.MostrarInformacion("Archivo no cargado");	
				}
				else {
					VP.getDerecha().setCampoTexto(EA.readFile());
					//Mostrar en VP "Archivo cargado con éxito"
				}
			}
		}
		else if(command.equals("buscar")) {
			String res = VV.leerString("Ingrese la palabra que quiere buscar");
			ArrayList<Integer> index = KMP.kmpSearch(VP.getDerecha().getCampoTexto(), res);
			try {
				if(index.size() == 0 || index == null) {
					HL.removeAllHighlights();
					VV.MostrarInformacion("No hay coincidencias");
					VP.getDatos().setContador("0");
					
				}
				else {
					//La cantidad de indices que haya en el array, será la cantidad que debe 
					//Aumentar las palabras encontradas
					VP.getDatos().setContador(index.size() + "");
					HighlightPainter p = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
					HL.removeAllHighlights();
					for(int x : index) {
						int p1 = x + res.length();
						try {
							HL.addHighlight(x - 1, p1 - 1, p);
						} catch (BadLocationException e1) {
							//e1.printStackTrace();
							
						}
					}
				}
			}catch(NullPointerException l) {
				VV.MostrarInformacion("Debe ingresar una palabra");
			}
			
			System.out.println("Index: " + index);
		}
		else if(command.equals("salir")) {
			VV.MostrarInformacion("Gracias por usar nuestro software");
			//Agregar ventana emergente de despedida
			System.exit(0);
		}
	}

}
